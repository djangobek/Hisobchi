# Hisobchi AI v3 — o'zgarishlar

Fayllarni loyihadagi o'z joyiga qo'ying (ustiga yozing):
- src/app/api/ai/route.ts
- src/components/ai-advisor.tsx
- src/app/globals.css
- .env.example

.env:  GEMINI_MODEL=gemini-3.5-flash-lite,gemini-3.8-flash
Baza migratsiyasi kerak emas.
