export function formatUZS(value: number | string | { toString(): string }): string {
  const amount = Number(value);
  if (!Number.isFinite(amount)) return "0 so‘m";
  return `${new Intl.NumberFormat("uz-UZ", { maximumFractionDigits: 0 }).format(amount).replace(/\u00a0/g, " ")} so‘m`;
}
export function parseAmount(value: string): number {
  const normalized = value.replace(/[^\d,.-]/g, "").replace(/\s/g, "").replace(",", ".");
  const amount = Number(normalized);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Summa noldan katta bo‘lishi kerak.");
  return amount;
}