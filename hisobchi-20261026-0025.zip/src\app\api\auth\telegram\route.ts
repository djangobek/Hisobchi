import { NextRequest, NextResponse } from "next/server";
import { validateTelegramInitData } from "@/lib/telegram";
import { prisma } from "@/lib/prisma";
import { z } from "zod";
export const runtime="nodejs";
export async function POST(req:NextRequest){
 try{
  const body=z.object({initData:z.string().min(1)}).parse(await req.json());
  const tg=validateTelegramInitData(body.initData,process.env.BOT_TOKEN??"",Number(process.env.TELEGRAM_INIT_DATA_MAX_AGE_SECONDS??86400));
  const user=await prisma.user.upsert({where:{telegramId:String(tg.id)},update:{firstName:tg.first_name,lastName:tg.last_name,username:tg.username},create:{telegramId:String(tg.id),firstName:tg.first_name,lastName:tg.last_name,username:tg.username}});
  return NextResponse.json({id:user.id,firstName:user.firstName,username:user.username});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Autentifikatsiya bajarilmadi."},{status:401});}
}