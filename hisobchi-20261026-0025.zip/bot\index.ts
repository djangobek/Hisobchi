import { Bot, InlineKeyboard } from "grammy";
import { PrismaClient } from "@prisma/client";
import { monthBounds } from "../src/lib/dates";

const token = process.env.BOT_TOKEN;
if (!token) { console.error("BOT_TOKEN .env faylida ko'rsatilmagan."); process.exit(1); }

const bot = new Bot(token);
const prisma = new PrismaClient();

async function getUser(ctx: any) {
  const id = ctx.from?.id;
  if (!id) return null;
  return prisma.user.findUnique({ where: { telegramId: String(id) } });
}

async function isMaintenance() {
  const s = await prisma.appSetting.findUnique({ where: { key: "maintenance_mode" } });
  return s?.value === "true";
}

bot.command("start", async ctx => {
  if (await isMaintenance()) {
    const msg = await prisma.appSetting.findUnique({ where: { key: "maintenance_message" } });
    return ctx.reply(msg?.value ?? "🛠 Texnik ishlar ketmoqda.");
  }
  const user = await getUser(ctx);
  if (user?.blockedBot) {
    await prisma.user.update({ where: { id: user.id }, data: { blockedBot: false } });
  }
  const url = process.env.WEB_APP_URL;
  const keyboard = url ? new InlineKeyboard().webApp("Hisobimni ochish", url) : undefined;
  await ctx.reply("Assalomu alaykum! 👋\n\nHisobchi — daromad, xarajat va qarzlaringizni tartib bilan yuritish uchun shaxsiy moliya yordamchisi.\n\nMini App'ni ochib, moliyaviy qaydlaringizni boshqaring.", { reply_markup: keyboard });
});

bot.command("admin", async ctx => {
  const user = await getUser(ctx);
  if (!user || user.role !== "ADMIN") return ctx.reply("Ruxsat yo'q.");
  const url = process.env.WEB_APP_URL;
  if (!url) return ctx.reply("WEB_APP_URL sozlanmagan.");
  await ctx.reply("🛡 Admin panelga o'tish:", {
    reply_markup: new InlineKeyboard().webApp("Admin panelni ochish", url),
  });
});

bot.command("today", async ctx => {
  if (await isMaintenance()) return ctx.reply("🛠 Texnik ishlar ketmoqda.");
  const user = await getUser(ctx);
  if (!user) return ctx.reply("Avval Mini App'ni ochib, hisobingizni yarating.");
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const end = new Date(start); end.setDate(end.getDate() + 1);
  const rows = await prisma.transaction.findMany({ where: { userId: user.id, occurredAt: { gte: start, lt: end } } });
  const income = rows.filter(t => t.type === "INCOME").reduce((s, t) => s + Number(t.amount), 0);
  const expense = rows.filter(t => t.type === "EXPENSE").reduce((s, t) => s + Number(t.amount), 0);
  return ctx.reply(`📅 Bugungi hisobot\n\n🟢 Tushum: ${income.toLocaleString("uz-UZ")} so'm\n🔴 Xarajat: ${expense.toLocaleString("uz-UZ")} so'm\n⚖️ Farq: ${(income - expense).toLocaleString("uz-UZ")} so'm`);
});

bot.command("month", async ctx => {
  if (await isMaintenance()) return ctx.reply("🛠 Texnik ishlar ketmoqda.");
  const user = await getUser(ctx);
  if (!user) return ctx.reply("Avval Mini App'ni ochib, hisobingizni yarating.");
  const now = new Date(), bounds = monthBounds(now.getFullYear(), now.getMonth());
  const rows = await prisma.transaction.findMany({ where: { userId: user.id, occurredAt: { gte: bounds.start, lt: bounds.end } } });
  const income = rows.filter(t => t.type === "INCOME").reduce((s, t) => s + Number(t.amount), 0);
  const expense = rows.filter(t => t.type === "EXPENSE").reduce((s, t) => s + Number(t.amount), 0);
  return ctx.reply(`📊 ${now.toLocaleDateString("uz-UZ", { month: "long", year: "numeric" })}\n\n🟢 Tushum: ${income.toLocaleString("uz-UZ")} so'm\n🔴 Xarajat: ${expense.toLocaleString("uz-UZ")} so'm\n⚖️ Farq: ${(income - expense).toLocaleString("uz-UZ")} so'm`);
});

bot.command("debts", async ctx => {
  if (await isMaintenance()) return ctx.reply("🛠 Texnik ishlar ketmoqda.");
  const user = await getUser(ctx);
  if (!user) return ctx.reply("Avval Mini App'ni ochib, hisobingizni yarating.");
  const rows = await prisma.debt.findMany({ where: { userId: user.id, status: { not: "PAID" } }, include: { payments: true } });
  if (!rows.length) return ctx.reply("Hozircha ochiq qarzlar yo'q.");
  const lines = rows.map(d => {
    const paid = d.payments.reduce((s, p) => s + Number(p.amount), 0);
    return `${d.direction === "LENT" ? "↗️ Bergan" : "↙️ Olgan"} · ${d.personName}: ${(Number(d.originalAmount) - paid).toLocaleString("uz-UZ")} so'm`;
  });
  return ctx.reply("💳 Ochiq qarzlar\n\n" + lines.join("\n"));
});

bot.catch(async err => {
  console.error("Bot error:", err.error);
  const chatId = err.ctx?.from?.id;
  if (chatId && err.error instanceof Error && /blocked|forbidden/i.test(err.error.message)) {
    try {
      await prisma.user.updateMany({
        where: { telegramId: String(chatId) },
        data: { blockedBot: true },
      });
    } catch {}
  }
});

bot.start({ onStart: () => console.log("Hisobchi bot ishga tushdi.") });
process.once("SIGINT", () => { bot.stop(); void prisma.$disconnect(); });
process.once("SIGTERM", () => { bot.stop(); void prisma.$disconnect(); });