import { NextRequest,NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { transactionSchema } from "@/lib/validation";
import { getAuthUser } from "@/lib/auth";
export const runtime="nodejs";
async function authenticated(req:NextRequest){ return getAuthUser(req); }
export async function GET(req:NextRequest){try{const user=await authenticated(req);const from=req.nextUrl.searchParams.get("from"),to=req.nextUrl.searchParams.get("to");const rows=await prisma.transaction.findMany({where:{userId:user.id,...(from||to?{occurredAt:{...(from?{gte:new Date(from)}:{}),...(to?{lt:new Date(to)}:{})}}:{})},include:{category:{select:{id:true,name:true,type:true}}},orderBy:{occurredAt:"desc"},take:500});return NextResponse.json(rows);}catch(e){return NextResponse.json({error:e instanceof Error?e.message:"So‘rov bajarilmadi."},{status:401});}}
export async function POST(req:NextRequest){try{const user=await authenticated(req);const input=transactionSchema.parse(await req.json());const category=await prisma.category.findFirst({where:{id:input.categoryId,userId:user.id,type:input.type}});if(!category)return NextResponse.json({error:"Kategoriya topilmadi."},{status:400});if(input.accountId){const account=await prisma.account.findFirst({where:{id:input.accountId,userId:user.id}});if(!account)return NextResponse.json({error:"Hisob topilmadi."},{status:400});}if (input.requestKey) {
  const existing = await prisma.transaction.findUnique({ where: { userId_requestKey: { userId: user.id, requestKey: input.requestKey } }, include: { category: true } });
  if (existing) return NextResponse.json(existing, { status: 200 });
}
const row=await prisma.transaction.create({data:{userId:user.id,amount:input.amount,type:input.type,categoryId:category.id,accountId:input.accountId||null,note:input.note,occurredAt:input.occurredAt,requestKey:input.requestKey},include:{category:true}});return NextResponse.json(row,{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Ma’lumotlarni saqlashda xatolik."},{status:400});}}